import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./../pages/Login";
import Dashboard from "./../pages/Dashboard";
import Profile from "./../pages/Profile";
import NotFound from "./../pages/NotFound";
import PrivateRoute from "./PrivateRoute";

const AppRoute = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/" element={<Login />} />
        <PrivateRoute exact path="/dashboard" element={<Dashboard />} />
        <PrivateRoute exact path="/profile" element={<Profile />} />
        <Route exact path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRoute;
