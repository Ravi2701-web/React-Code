import React from "react";
import MasterLayout from "../layout/MasterLayout";

const NotFound = () => {
  return (
    <MasterLayout>
      <h1>NotFound</h1>
    </MasterLayout>
  );
};

export default NotFound;
