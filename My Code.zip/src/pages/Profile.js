import React from "react";
import MasterLayout from "../layout/MasterLayout";

const Profile = () => {
  return (
    <MasterLayout>
      <h1>Profile</h1>
    </MasterLayout>
  );
};

export default Profile;
